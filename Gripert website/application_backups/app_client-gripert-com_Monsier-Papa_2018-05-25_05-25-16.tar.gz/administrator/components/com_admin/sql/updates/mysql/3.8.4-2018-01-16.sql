ALTER TABLE `#__user_keys` DROP INDEX `series_2`;
ALTER TABLE `#__user_keys` DROP INDEX `series_3`;
